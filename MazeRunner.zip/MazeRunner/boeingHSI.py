# -*- coding: utf-8 -*-
"""
Created on Mon Aug  3 19:40:37 2020

@author: Nathan Zhang
"""


from BoeingHSILead import Phillllllip

def main():
    beABoeingLead()
    uhOhEmergency()
    
def beABoeingLead():
    callAMeeting(8/3/2020, 10:00)
    runAMile()
    driveToTheBeach(Bolsa Chica, 4:00)
    haveFunAtTheBeach()
    
def uhOhEmergency():
    goToTheERAfterBeachBonding(8/1/2020, 11:00, 
                               "immense amount of blood coming from my foot")