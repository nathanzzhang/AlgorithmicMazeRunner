# -*- coding: utf-8 -*-
"""
Created on Tue Jul 28 13:39:11 2020

@author: Nathan Zhang
"""


class GuidanceAlgorithm:
    
    def __init__(self, leftZone, rightZone, frontZone):
        self.mLeftBlocked = leftZone
        self.mRightBlocked = rightZone
        self.mFrontBlocked = frontZone
        
   